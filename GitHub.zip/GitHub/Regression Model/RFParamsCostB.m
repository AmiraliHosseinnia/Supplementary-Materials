function [z,Out] = RFParamsCostB(x,Model)

Features = Model.Feature;

Labels = Model.Label;
K = Model.K;
CVI = Model.CVI;

%% Map the x into FR parameyters
Options = MapVar2Params(x,Features);

AccuracyTrain = zeros(1,K);
AccuracyValid = zeros(1,K);

for i = 1:K

    TrainF = Features(CVI~=i,:);
    TrainL = Labels(CVI~=i);

    Classify = TreeBagger(Options.nTrees,TrainF,TrainL,...
        'NumPredictorsToSample',Options.NumPredictorsToSample,...
        'MaxNumSplits',Options.MaxNumSplits,...
        'MinLeafSize',Options.MinLeafSize,...
        'PredictorSelection',Options.PredictorSelection,...
        'MergeLeaves',Options.MergeLeaves , ...
        'OOBPrediction','on',...
        'Method','regression');

    ClassT = predict(Classify,TrainF);

    SSR = sum((ClassT - TrainL).^2);
    % Total sum of squares
    TSS = sum(((TrainL - mean(TrainL)).^2));
    % R squared
    Rsquared = 1 - SSR/TSS;
    AccuracyTrain(i) = Rsquared;

    ValidF = Features(CVI==i,:);
    ValidL = Labels(CVI==i);

    ClassV = predict(Classify,ValidF);
    SSR = sum((ClassV - ValidL).^2);
    % Total sum of squares
    TSS = sum(((ValidL - mean(ValidL)).^2));
    % R squared
    Rsquared = 1 - SSR/TSS;
    AccuracyValid(i)=Rsquared;
    

    Cl(i).Classify = Classify;

end
% toc
% disp(Options)

AccuracyValid1 = mean([AccuracyTrain;AccuracyValid]);
[~,idxm] = max(AccuracyValid1);
Classify = Cl(idxm).Classify;


z = - mean(AccuracyValid1);

Out.z = z;
Out.Classify = Classify;
Out.AccuracyValid = AccuracyValid;
Out.AccuracyTrain = AccuracyTrain;
Out.Data = Model;
Out.Params = Options;
end

function Options = MapVar2Params(x,Features)
[nObs,nVar] = size(Features);
% Set Hyper-Parameters
Options.nTrees = 100 + round(100*x(1));
Options.MaxNumSplits = 1 + round((nObs-1)*x(2));
Options.MinLeafSize = 1 + round(5*x(3));
Options.NumPredictorsToSample = 2 + round(5*nVar*x(4));

PredictorSelection = min(max(1,round(3*x(5))),3);
switch PredictorSelection
    case 1
        PredictorSelections = 'allsplits';
    case 2
        PredictorSelections =  'interaction-curvature';
    otherwise
        PredictorSelections =  'curvature' ;
end
Options.PredictorSelection = PredictorSelections;


Options.MergeLeaves = 'off';

end


