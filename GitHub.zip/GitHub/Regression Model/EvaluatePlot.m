function Results = EvaluatePlot(Data,Result,Name)
Function = Data.Function;

Classify = Result.Out.Classify;
Features = Data.Feature;

Targets = Data.Label;
[Groups,Score] = predict(Classify,Features);
SSR = sum((Groups - Targets).^2);
% Total sum of squares
TSS = sum(((Targets - mean(Targets)).^2));
% R squared
Rsquared = 1 - SSR/TSS;
Results.Rsquared = Rsquared;




