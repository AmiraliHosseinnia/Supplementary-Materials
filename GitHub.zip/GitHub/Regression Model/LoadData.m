function [TrainData,TestData] = LoadData(name)


%% Load Data
data = importdata(['DataSets/',name]);
if isstruct(data)
    data = data.data;
end
%% Manage Data


Labels = data(:,end);
Features = data(:,1:end-1);

% Normalization
%Features = rescale(Features);

% Divide TrianData And TestData
rng(0)
pT = 90;
[nSamples,nFeature] = size(Features);
nTrain = round((pT/100)*nSamples);

R=[48,44,18,76,33,12,26,71,39,16,34,43,13,9,53,51,58,29,77,6,57,24,22,52,55,75,14,25,46,32,35,38,11,10,50,61,8,69,1,72,64,28,67,59,68,66,54,45,15,73,36,2,65,56,63,7,40,37,5,19,62,41,4,74,49,27,17,47,30,42,23,70,21,31,20,3,60];
indTrain = R(1:nTrain);
indTest = R(nTrain+1:end);

TrainData.Feature = Features(indTrain,:);
TrainData.Label = Labels(indTrain);
TrainData.nFeature = nFeature;

TestData.Feature = Features(indTest,:);
TestData.Label = Labels(indTest);


% Apply K-Fold Cross Validation
K = 10;
NT = numel(indTrain);
CVI = crossvalind('kfold',NT,K);
TrainData.CVI = CVI;
TrainData.K = K;

end

function X = Normalaization(X,LB,UB)

Min = min(X);
Max = max(X);
if nargin<2
    LB = -1;
    UB = 1;
end

for i = 1:numel(Min)
    X(:,i) = (X(:,i) -Min(i))/(Max(i) - Min(i)) ;
end
X = (UB - LB)*X + LB;


end
