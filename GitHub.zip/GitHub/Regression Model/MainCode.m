clc
clear
close all


%% Optimization of RF Parameters Using GA

%% load Data Results 
NameData = 'mydata.mat';

[TrainModel,TestData] = LoadData(NameData);


%% Function Selection 
Functions = {'Ensemble','Bagger'};
Function = Functions{2};
TrainModel.Function = Function;
TestData.Function = Function;

%% MA Sets Params
Params.nPop = 3;
Params.MaxIt   = 2;

%% Optimize RF using GA
Results = OptimizeRFusingGA(TrainModel,Params);


%% Prediction AND Evaluation Confusion Matrix & ROC
ResultsTrain = EvaluatePlot(TrainModel,Results,' Train ');
ResultsTest = EvaluatePlot(TestData,Results,' Test ');


%% Display
disp('********* Results **********');
disp(ResultsTrain);
disp(ResultsTest);
disp('******** RF Params *********');
disp(Results.Out.Params)
disp('********* Final Results *******')


