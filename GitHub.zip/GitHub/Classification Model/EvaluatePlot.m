function Results = EvaluatePlot(Data,Result,Name)
Function = Data.Function;

Classify = Result.Out.Classify;
Features = Data.Feature;

Targets = Data.Label;
[Groups,Score] = predict(Classify,Features);
if contains(Function,'Bag')
Groups = str2num(cell2mat(Groups));
end
confmat = confusionmat(Targets,Groups);
Results = PrecisionRecall(confmat);

[Targets,Groups] = H_MultiClassCMROC(Targets',Groups');
figure,plotconfusion(Targets,Groups)
title(['CM for ',Name,' Data'])
for i = 1:size(confmat,1)
[~,~,~,AUC(i)] = perfcurve(Targets(i,:),Score(:,i)',1);
end
Results.AUC = AUC;
% disp(['Results For ',Name,' Data'])
% disp(Results)
% disp(' **************************')
figure,plotroc(Targets(:,:),Score(:,:)')
title(['ROC for ',Name,' Data'])
end

function [Targets,Groups] = H_MultiClassCMROC(Targets,Groups)

Tu = unique(Targets);
Temp1 = zeros(size(Targets));
Temp2 = Temp1;
for i = 1:numel(Tu)
  Ind1 = find(Targets==Tu(i));
  Temp1(Ind1) = i; %#ok
  
  Ind2 = find(Groups==Tu(i));
  Temp2(Ind2) = i;  %#ok
  
end
  
Targets = full(ind2vec(Temp1));
Groups = full(ind2vec(Temp2));
end

function Results = PrecisionRecall(confmat)

nC = size(confmat,1);
for i = 1:nC
Precision(i) = confmat(i,i)/sum(confmat(:,i))*100;
Recall(i) = confmat(i,i)/sum(confmat(i,:))*100;
F1_Score(i) = 2*Precision(i)*Recall(i)/(Precision(i)+Recall(i));
end

Accuracy = sum(diag(confmat))/sum(confmat(:));
Results.Accuracy = Accuracy;
Results.Precision = Precision;
Results.Recall = Recall;
Results.F1_Score = F1_Score;
% disp(Results)
end